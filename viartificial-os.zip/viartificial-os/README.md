# ViArtificial OS — la Coquille (kernel / "OS motor AI")

Le **shell** de ton OS web, **sans interface**. Que la logique : noyau + orchestrateur + moteurs.
L'**UI (HTML/CSS) se fera séparément** et importera juste `boot.js`.

C'est la pièce qui te manquait : **un orchestrateur central** qui relie tout et fait tourner une vraie boucle.

## Fichiers (ES modules, ZÉRO dépendance)
- `boot.js` — point d'entrée → `bootViArtificialOS()`.
- `kernel.js` — le noyau/orchestrateur (séquence de boot, boucle, API publique).
- `config.js` — config canonique (splits, ratios BERG, états, apps). **Source de vérité unique.**
- `bus.js` — Réseau Maillé (bus d'événements pub/sub).
- `store.js` — état partagé + SLC SYNC (superposition de couches, jamais écraser).
- `clock.js` — CRON SYSTEM / cœur + RAF SAMPLER (FPS & drift **réels**).
- `telemetry.js` — SUPERSAM A (vrais signaux : cœurs, mémoire, batterie\*, réseau, visibilité).
- `vfs.js` — système de fichiers sur OPFS (sandbox, marche sur iOS) + repli mémoire.
- `processes.js` — apps/fenêtres (logique) ; cycle ACTIF→PASSIF→DORMANT→ZOMBIE.
- `pawa.js` — économie PAWA/BERG **gamifiée** + effectualisation (signaux réels).
- `motors.js` — cadre des 26 moteurs (classe `Motor` + hôte + 4 moteurs réels branchés).
- `persist.js` — SLC SYNC : sauvegarde/restauration (snapshots empilés en OPFS).

## Démarrer (depuis le futur HTML, séparé)
```html
<script type="module">
  import { bootViArtificialOS } from './boot.js';
  const ViA = await bootViArtificialOS();

  ViA.on('boot:done', s => console.log('OK', s));
  ViA.launch('golemotor');

  // l'UI lira l'état à chaque frame :
  ViA.store.subscribe(state => {
    // state.fps, state.driftMs, state.pawaBank, state.effectualisation, state.passports...
  });
</script>
```
> À servir en **https (GitHub Pages)** ou **localhost** : modules + OPFS l'exigent.

## Ajouter un moteur (tes 26)
```js
import { Motor } from './motors.js';
class TsimtsoumCompressor extends Motor {
  constructor(){ super('TSIMTSOUM', { node:'ALL', priority: 40 }); }
  async boot(kernel){ await super.boot(kernel); }
  tick(ctx){ /* ta logique, accès via this.kernel */ }
}
ViA.registerMotor(new TsimtsoumCompressor());
```
`priority` bas = démarre en premier (SUPERSAM A = 0).

## Ajouter une app
```js
ViA.registerApp({ id:'mon-app', name:'Mon App', icon:'★' });
const proc = ViA.launch('mon-app');   // -> ACTIF
ViA.kill(proc.pid);                    // -> ZOMBIE (puis recyclé par RecyclatingCore)
```

## Honnête — les limites du navigateur (à garder en tête)
- \*Batterie : lue **seulement** sur Chrome/Android. **Pas sur iOS/Safari** → `available:false`. Jamais modifiée.
- VFS = stockage **privé de l'app** (OPFS), **pas** le disque système ni les autres apps.
- PAWA/BERG = points internes **gamifiés**, pas des watts physiques.
- Pas d'accès au système global : la coquille reste dans le bac à sable du navigateur.

## Revitalizor (FAIT) — JS, agit sur la data réelle de l'app
- `revitalizor.js` — arène mémoire + presse-papier Mattern (copy/delete/paste), **défrag réel**,
  intégrité (hash), **heal** depuis fantôme, mint PAWA. Branché dans le moteur `RECYCLATING_CORE`.
- `revitalizor.worker.js` — Web Worker : hash + sauvegarde chunkée OPFS **hors thread principal**.
- `revitalizor.config.json` — tunables (taille arène, seuil défrag, intégrité, transfert).

## Les 26 moteurs (FAIT) — 26 fichiers JSON + loader
- `motors/01-…json` … `motors/26-…json` — une spec par moteur (id, catégorie, nœud, priorité, impl, rôle).
- `motors/index.json` — liste lue par le loader.
- `motors-loader.js` — `loadMotors(ViA)` : crée les moteurs, donne un comportement **réel**
  aux impls réelles (telemetry / metadata / mining / revitalizor / pawa / clock), **symbolique** au reste.
- `boot.js` charge déjà tout ça automatiquement.

> Note honnête : `.json` ne « modifie » rien tout seul (données), `.py` ne tourne ni dans la PWA ni sur iOS.
> Le moteur qui agit sur le device via le navigateur est le JS (cœurs via Worker, stockage via OPFS).

## Interface (FAIT) — `interface.html`, alchimiste cyberfun
Un seul fichier, polices système (rien à charger), relié à **toute la coquille ET aux 26 moteurs** :
- **Athanor** central (Recyclating Core) : PAWA_BANK + effectualisation + battement FPS, anneau des 4 nœuds.
- **Boost Engine (AUTO)** : passe en mode BOOST et fait tourner la boucle tout seul (forge→recycle→défrag→mint), auto-réglé sur le FPS réel. Anime le moteur interne, n'accélère pas le hardware.
- **Revitalizor** interactif : forger / sauver(copy) / corrompre / cycle / supprimer / recoller + barre d'arène.
- **Télémétrie** réelle (cœurs, mémoire, batterie\*, réseau, FPS/drift) — "non dispo" honnête sur iOS.
- **Lanceur** des 7 apps → fenêtres draggables avec cycle ACTIF→PASSIF→DORMANT→ZOMBIE.
- **Grille des 26 moteurs** en direct (réel vs symbolique), qui pulsent sur les événements du bus.
- **Grimoire** : flux temps réel du Réseau Maillé.

Ouvre `interface.html` **via https** (GitHub Pages) ou un serveur local
(`python3 -m http.server` dans le dossier) — `file://` est bloqué (modules + OPFS + fetch JSON).
